package song;
import java.util.Scanner;
public class Judgment_Anomaly_14 {
public static void main(String args[])
{
 Scanner sc = new Scanner(System.in);
 Person person = new Person();
 person.setAge(sc.nextInt());
 person.setSex(sc.next());
 person.setName(sc.next());
 person.talk();
	}
}
class Person
{
     String name;
	 int age;
	 String sex;
	void setAge(int age)
	{
		try
		{
			if(age > 1 && age <100)
			{
				this.age = age;
			}
			}catch(Exception e)
			{	e.printStackTrace();
				System.out.println("年龄必须在1到100之间！");
			}
				
		
	}
	void setSex(String sex)
	{
		
				this.sex = sex;
		
		}
	public void setName(String name) {
		this.name = name;
	}
	
	void talk()
	{
		System.out.println("name:"+name+"\nage:"+age+"\nsex:"+sex);
	}
	}
	
